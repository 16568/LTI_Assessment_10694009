package com.lti.SSA;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.data.repository.CrudRepository;
import javax.persistence.Entity;

@DataJpaTest
@AutoConfigureTestDatabase(replace= Replace.NONE)
@Rollback(false)
public class SSATest {

	@Autowired
	private SmartShopRepository smartrepo;
	
	@Autowired
	private TestEntityManager Entity;
	
	@Test
	public void testAddSmartShopItems()
	{
		Product product =Entity.find(product.class,primarykey);
	}
}
