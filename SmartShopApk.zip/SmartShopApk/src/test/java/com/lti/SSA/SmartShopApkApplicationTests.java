package com.lti.SSA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartShopApkApplicationTests {

	@Test
	void contextLoads() {
	}

}
