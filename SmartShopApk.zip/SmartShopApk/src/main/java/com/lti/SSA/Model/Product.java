package com.lti.SSA.Model;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product
{

  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  private long productid;

  @Column(name="product", nullable=false)
  private String product;
  
  @Column(name="productName", nullable=false)
  private String productName;

  @Column(name="quantity", nullable=false)
  private int qty;
  
  @Column(name="catagory", nullable=false)
  private String catagory;

  @Column(name="Unitprice", nullable=false)
  private double unitPrice;

  @Column(name="total_price", nullable=false)
  private long tp;

  @Column(name="Rating", nullable=false)
  private long rating;

 


public Product(long id, String product, String productName, int qty, int ctg, long unitPrice, long tp, long rating) {
	super();
	this.productid = id;
	this.product = product;
	this.productName = productName;
	this.qty = qty;
	this.catagory = catagory;
	this.unitPrice = unitPrice;
	this.tp = tp;
	this.rating = rating;
}

public long getId() {
	return productid;
}

public void setId(long id) {
	this.productid = id;
}

public String getProduct() {
	return product;
}

public void setProduct(String product) {
	this.product = product;
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public int getQty() {
	return qty;
}

public void setQty(int qty) {
	this.qty = qty;
}

public String getCatagory() {
	return catagory;
}

public void setCatagory(String catagory) {
	this.catagory = catagory;
}

public double getUnitPrice() {
	return unitPrice;
}

public void setUnitPrice(double unitPrice) {
	this.unitPrice = unitPrice;
}

public long getTp() {
	return tp;
}

public void setTp(long tp) {
	this.tp = tp;
}

public long getRating() {
	return rating;
}

public void setRating(long rating) {
	this.rating = rating;
}

public Product()
  {
  }

@Override
public String toString() {
	return "Product [id=" + productid + ", product=" + product + ", productName=" + productName + ", qty=" + qty
			+ ", catagory=" + catagory + ", unitPrice=" + unitPrice + ", tp=" + tp + ", rating=" + rating + "]";
}




 

 
 
}