package com.lti.SSA.Exception;

public class Exception {

}
