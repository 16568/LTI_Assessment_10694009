package com.lti.SSA.Service.Impl;



import com.lti.SSA.Dao.ProductRepository;
import com.lti.SSA.Model.Product;
import com.lti.SSA.Service.ProductService;
import com.lti.SSA.Dao.ProductRepository;
import com.lti.SSA.Model.Product;
import com.lti.SSA.Service.ProductService;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional

public class SmartShopServiceImpl implements ProductService {
	
	 @Autowired
	  private ProductRepository productRepositoryDao;

	  public Product findProductByCatagory(String catagory)
	  {
	    return this.productRepositoryDao.findProcductByCatagory(catagory);
	  }

	  public Iterable<Product> getAllTickets()
	  {
	    return this.productRepositoryDao.findAll();
	  }

	  public Product findProductById(Integer productId)
	  {
	    return (Product)this.productRepositoryDao.findAll(productId).get();
	  }

	  public Product updateEmailById(Integer productId, String email)
	  {
		  Product product = (Product)this.productRepositoryDao.findById(productId).get();
		  product.setCatogory(catagory);
	    return (Product)this.productRepositoryDao.save(product);
	  }

	  public boolean deleteProductById(Integer productId)
	  {
	    this.productRepositoryDao.deleteById(productId);
	    Product product = (Product)this.productRepositoryDao.findById(productId).get();

	    return product == null;
	  }

	  public Product createProduct(Product product)
	  {
	    return (Product)this.productRepositoryDao.save(product);
	  }

}





