package com.lti.SSA.Controller;


import com.lti.SSA.Exception.ResourceNotFoundException;
import com.lti.SSA.Model.Product;
import com.lti.SSA.Service.ProductService;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/smartshop"})
public class ProductController
{

  @Autowired
  ProductService SmartShopdetails;

  
  
  
  @GetMapping({"/getAllProducts"})
  public List<Product> getAllProducts()
  {
    return (List)this.SmartShopdetails.getAllProducts();
  }
  @GetMapping({"/getAllProductsById/{ProductId}"})
  public Product getProductsById(@PathVariable Integer ProductId) {
    return this.SmartShopdetails.findProductById(ProductId);
  }
  
  @PutMapping({"/updateProductsById/{/ticket/{ticketId}"})
  public Product updateProductByCatagory(@PathVariable String catagory,@PathVariable Integer productId) {
    return this.SmartShopdetails.updateProductByCatagory1(productId,catagory );
  }
  @PostMapping({"/createTicket"})
  public Product createProduct(@RequestBody Product product)
  {
    return this.SmartShopdetails.createProduct(product);
  }
  @DeleteMapping({"/deleteProductById/Product/{ProductId}"})
  public boolean deleteProductById(@PathVariable Integer ticketId) {
    return this.SmartShopdetails.deleteProductById(ticketId);
  }
  
 
}