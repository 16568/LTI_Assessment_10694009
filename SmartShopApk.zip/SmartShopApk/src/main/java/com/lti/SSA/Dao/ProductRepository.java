package com.lti.SSA.Dao;

import com.lti.SSA.Model.Product;
import java.time.LocalDate;
import java.util.List;


import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
@Transactional

public abstract interface ProductRepository extends JpaRepository<Product, Long>
{
	  @Query("select t from Ticket t where t.Catagory=:catagory")
	  public abstract Product findByCatagory(String paramString);
	}