package com.lti.SSA.Service;




import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.lti.SSA.Exception.ResourceNotFoundException;
import com.lti.SSA.Model.Product;







@Service

public abstract interface ProductService
{
  public abstract Product findProcductByCatagory(String paramString);

  public abstract Iterable<Product> getAllProducts();

  public abstract Product findProductById(Integer paramInteger);

  public abstract Product updateProductByCatagory(Integer paramInteger, String paramString);

  public abstract boolean deleteProductById(Integer paramInteger);

  public abstract Product createProduct(Product paramProduct);

public abstract Product updateProductByCatagory1(Integer productId, String catagory);
}




//public class ProductService {
//
//	@Autowired
//	ProductRepository productrep;
//	
//	public LocalDate CalculateTotalPrice( long productid) throws ResourceNotFoundException{
//		Product prod=productrep.findById(productid)
//				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productid));
//		
//		
//		return Product;
//	}
//	
//	public Product CreateProduct(Product product) {
//		return productrep.save(product);
//	}
//	public List<Product> SortProducts(){
//		
//		return productrep.sortByExpiryDate();
//		
//	}
//	
//public void RemoveExpiry() {
//		List<Product> prod=productrep.findAll();
//		LocalDate today=LocalDate.now();
//		List<Product> filteredlist=prod.stream().filter(p->p.getExpiry().isBefore(today)).collect(Collectors.toList());
//		for(Product p: filteredlist) {
//			productrep.delete(p);
//		}
//		
//	}
//
//public void ApplyDiscounts() {
//	List<Product> prod=productrep.findAll();
//	LocalDate today=LocalDate.now();
//	for(Product p: prod) {
//		if(ChronoUnit.MONTHS.between(p.getExpiry(), today)<6) {
//			productrep.Discount(p.getId());
//		}
//	}
//}
//
//public Optional<Product> Search(long productid) {
//	
//	return productrep.findById( productid);
//}
//
//
//}
