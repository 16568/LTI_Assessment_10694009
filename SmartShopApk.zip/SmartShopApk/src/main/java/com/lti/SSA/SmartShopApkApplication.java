package com.lti.SSA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartShopApkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartShopApkApplication.class, args);
	}

}
